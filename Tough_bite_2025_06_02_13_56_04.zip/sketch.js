// Campo interativo para cidade com árvores que podem ser plantadas clicando (p5.js)

// Array para armazenar as árvores
let trees = [];
// Array para as nuvens animadas
let clouds = [];

function setup() {
  createCanvas(800, 600);
  // Plantar algumas árvores iniciais
  trees.push(new Tree(150, height - 140));
  trees.push(new Tree(350, height - 160));
  trees.push(new Tree(600, height - 130));
  // Criar nuvens iniciais
  for(let i = 0; i < 5; i++) {
    clouds.push(new Cloud(random(width), random(40, 100), random(60, 120)));
  }
  noLoop(); // Só redesenhar quando precisar
}

function draw() {
  background('#87ceeb'); // céu azul

  drawSun();
  drawField();
  drawRiver();
  drawHouses();

  // Desenha e anima as nuvens
  clouds.forEach(c => {
    c.move();
    c.display();
  });

  // Desenha as árvores
  trees.forEach(tree => tree.display());
}

// Desenha o sol com raios
function drawSun() {
  push();
  noStroke();
  fill('#ffdd55');
  ellipse(70, 70, 100, 100);
  stroke('#ffdd55');
  strokeWeight(3);
  for(let angle = 0; angle < TWO_PI; angle += PI/8) {
    let x1 = 70 + cos(angle) * 50;
    let y1 = 70 + sin(angle) * 50;
    let x2 = 70 + cos(angle) * 70;
    let y2 = 70 + sin(angle) * 70;
    line(x1, y1, x2, y2);
  }
  pop();
}

// Desenha o campo verde com textura de grama
function drawField() {
  noStroke();
  fill('#4caf50');
  rect(0, height * 0.5, width, height*0.5);

  stroke('#388e3c');
  strokeWeight(1);
  for(let x=10; x < width; x += 15) {
    for(let y=height*0.5+10; y < height; y += 20) {
      line(x, y, x+5, y-7);
    }
  }
}

// Desenha um rio sinuoso
function drawRiver() {
  noStroke();
  fill('#42a5f5');
  beginShape();
  vertex(0, height*0.8);
  bezierVertex(width*0.3, height*0.7, width*0.6, height*0.95, width, height*0.85);
  vertex(width, height);
  vertex(0, height);
  endShape(CLOSE);
}

// Desenha casas simples
function drawHouses() {
  const baseY = height * 0.5;
  const w = 80;
  const h = 60;
  drawHouse(220, baseY, w, h, '#f44336', '#b71c1c');
  drawHouse(520, baseY + 10, w, h, '#ffb74d', '#e65100');
}

function drawHouse(x, y, w, h, baseColor, roofColor) {
  noStroke();
  fill(baseColor);
  rect(x, y - h, w, h, 8);
  fill(roofColor);
  triangle(x - 10, y - h, x + w/2, y - h - h/2, x + w + 10, y - h);
  fill('#ffffffcc');
  rect(x + w*0.3, y - h/2, w*0.15, h*0.3, 3);
  rect(x + w*0.6, y - h/1.5, w*0.15, h*0.2, 3);
}

// Classe para árvores
class Tree {
  constructor(x, y) {
    this.x = x;
    this.y = y;
  }
  display() {
    noStroke();
    fill('#6d4c41');
    rect(this.x - 7, this.y + 10, 14, 40, 5);
    fill('#2e7d32');
    ellipse(this.x, this.y, 60, 80);
    fill('#43a04788');
    ellipse(this.x - 15, this.y - 10, 40, 50);
  }
}

// Classe para nuvens
class Cloud {
  constructor(x, y, size) {
    this.x = x;
    this.y = y;
    this.size = size;
    this.speed = random(0.2, 0.5);
  }
  move() {
    this.x += this.speed;
    if(this.x - this.size > width) {
      this.x = -this.size;
    }
  }
  display() {
    noStroke();
    fill(255, 240);
    ellipse(this.x, this.y, this.size, this.size * 0.6);
    ellipse(this.x + this.size*0.4, this.y + 10, this.size*0.75, this.size * 0.5);
    ellipse(this.x - this.size*0.4, this.y + 8, this.size*0.7, this.size * 0.5);
  }
}

// Plantar árvore ao clicar no campo
function mousePressed() {
  if(mouseY > height*0.5 && mouseY < height) {
    trees.push(new Tree(mouseX, mouseY - 30));
    redraw();
  }
}

